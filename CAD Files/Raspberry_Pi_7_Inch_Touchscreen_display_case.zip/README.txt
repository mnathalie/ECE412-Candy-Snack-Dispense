                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:1585924
Raspberry Pi 7 Inch Touchscreen display case by luc_e is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Easy to print solid Raspberry Pi 2 or 3, Official 7 inch touchscreen case. I wanted to keep the black bezel look of the screen and not making it bigger. You will need 4 M3x6 or 8 screws to secure the back cover. There is room inside for the power cables. 
I will use this as a kiosk display and NAS for my Kodi player I have cut out some areas at the back where I can add velcro strips to mount a 2.5 inch HDD. 
Enjoy and show off your builds and mods.

Update 290516: Added 2cm Velcro lid and lid without HDD support.

Update 310516: Added new case with little door access to the SD card. Still need small pliers or pincet but it's easier than unscrewing the back lid.

Update 150317: Added split STL for front to enable print on small print beds.

Update 010118: Added split STL for case Left and Right to enable print on small print beds

Update 240418: Added the 123Design source files


# Print Settings

Printer: Prusa i3 Plus
Rafts: No
Supports: Yes
Resolution: 200 um
Infill: 20%

Notes: 
I used supports for the Case, others don't need support. To finish the print faster you can use 2 bottom and 3 top layers.